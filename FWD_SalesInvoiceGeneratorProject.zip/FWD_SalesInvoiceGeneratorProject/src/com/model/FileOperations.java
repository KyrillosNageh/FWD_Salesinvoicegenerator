package com.model;

import java.util.ArrayList;


public class FileOperations {

    private ArrayList<InvoiceHeader> InvoiceHeaderList;

	
	public ArrayList<InvoiceHeader> readFile()
	{
		return InvoiceHeaderList;
		
	}
	
	public void writeFile(ArrayList<InvoiceHeader> table)
	{
		//for()
		InvoiceHeaderList.equals(table);
	}
	
	
}
